import os
import subprocess
import tkinter as tk
from tkinter import messagebox, ttk
import threading
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# hitta venv-mappar
venvs = [
    d for d in os.listdir(BASE_DIR)
    if os.path.isdir(os.path.join(BASE_DIR, d)) and "venv" in d.lower()
]

if not venvs:
    messagebox.showerror("Fel", "Ingen venv hittades i mappen.")
    exit()


def run_python_in_venv(python_exe, script_path):
    """Kör python-scriptet i venv med smart fakes-progressbar och mörk design"""
    root = tk.Tk()
    root.title("Importerar Garmin-data")
    root.attributes("-fullscreen", True)
    root.configure(bg="#1e1e1e")
    root.bind("<Escape>", lambda e: root.destroy())  # escape för att stänga

    # Container för centrerad layout
    frame = tk.Frame(root, bg="#1e1e1e")
    frame.place(relx=0.5, rely=0.5, anchor="center")

    # Label
    tk.Label(
        frame, text="⏳ Importerar Garmin-data till Excel…",
        font=("Segoe UI", 24, "bold"),
        fg="#ffffff",
        bg="#1e1e1e"
    ).pack(pady=20)

    # Progressbar
    style = ttk.Style()
    style.theme_use('clam')
    style.configure("TProgressbar", troughcolor="#333333", background="#fd4d17")

    progress = ttk.Progressbar(frame, mode="determinate", length=400, maximum=100, style="TProgressbar")
    progress.pack(pady=10)

    percent_label = tk.Label(frame, text="0%", font=("Segoe UI", 18), fg="#ffffff", bg="#1e1e1e")
    percent_label.pack()

    progress_value = [0]  # lista för mutable värde

    # Starta Python-script i bakgrunden
    def run_script():
        subprocess.run([python_exe, script_path], cwd=BASE_DIR)

    script_thread = threading.Thread(target=run_script, daemon=True)
    script_thread.start()

    # Progress-logik
    def fake_progress():
        steps = 98
        total_time = 25  # sekunder till 98%
        interval = total_time / steps

        while progress_value[0] < 98:
            # Om scriptet är klart innan 98% → öka hastigheten 4×
            if not script_thread.is_alive():
                interval /= 4

            progress_value[0] += 1
            progress['value'] = progress_value[0]
            percent_label.config(text=f"{progress_value[0]}%")
            root.update_idletasks()
            time.sleep(interval)

        # Vänta tills scriptet är klart
        while script_thread.is_alive():
            time.sleep(0.1)

        # Hoppa till 100%
        progress['value'] = 100
        percent_label.config(text="100%")
        root.update_idletasks()
        time.sleep(0.5)
        root.destroy()

    threading.Thread(target=fake_progress, daemon=True).start()
    root.mainloop()


def activate_venv(venv_name):
    python_exe = os.path.join(BASE_DIR, venv_name, "Scripts", "python.exe")
    script_path = os.path.join(BASE_DIR, "import_garmin_to_excel.py")

    if not os.path.exists(python_exe):
        messagebox.showerror("Fel", f"Hittar inte:\n{python_exe}")
        return

    if not os.path.exists(script_path):
        messagebox.showerror("Fel", "Hittar inte import_garmin_to_excel.py")
        return

    run_python_in_venv(python_exe, script_path)


# Om bara en venv → kör direkt
if len(venvs) == 1:
    activate_venv(venvs[0])

# Flera → välj i fönster
else:
    root = tk.Tk()
    root.title("Välj venv")
    root.attributes("-fullscreen", True)
    root.configure(bg="#1e1e1e")  # mörk bakgrund

    # Escape för att stänga fönstret manuellt
    root.bind("<Escape>", lambda e: root.destroy())

    # Container för centrerad layout
    frame = tk.Frame(root, bg="#1e1e1e")
    frame.place(relx=0.5, rely=0.5, anchor="center")

    # Label
    tk.Label(
        frame, text="Välj vilken venv som ska aktiveras:",
        font=("Segoe UI", 20, "bold"),
        fg="#ffffff",
        bg="#1e1e1e"
    ).pack(pady=20)

    # Style för progressbar om du vill visa loading senare
    style = ttk.Style()
    style.theme_use('clam')
    style.configure("TProgressbar", troughcolor="#333333", background="#fd4d17")

    # Knappar
    for venv in venvs:
        tk.Button(
            frame,
            text=venv,
            command=lambda v=venv: (activate_venv(v), root.destroy()),
            font=("Segoe UI", 16, "bold"),
            bg="#555555",           # grå bakgrund
            fg="#ffffff",           # vit text
            activebackground="#777777",  # ljusare grå när tryckt
            activeforeground="#ffffff",
            relief="flat",
            padx=20, pady=10
        ).pack(fill="x", pady=10)
    
    root.mainloop()

    root.mainloop()
